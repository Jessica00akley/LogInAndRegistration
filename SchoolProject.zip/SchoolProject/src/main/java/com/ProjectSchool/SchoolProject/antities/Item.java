package com.ProjectSchool.SchoolProject.antities;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "items")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private int price;
    private int amount;
    @ManyToMany(fetch = FetchType.EAGER)
    private List<Category>categories;
    @ManyToMany(fetch = FetchType.EAGER)
private List<Brand>brands;
}
