package com.ProjectSchool.SchoolProject.Repositories;

import com.ProjectSchool.SchoolProject.antities.Item;
import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Transactional
public interface ItemRepository extends JpaRepository<Item,Long> {
    Item findAllById(Long id);
    List<Item>findAllByOrderByNameDesc();
    List<Item>findAllByOrderByNameAsc();
    List<Item>findAllByAmountEqualsOrPriceEquals(int sum,int price);
    List<Item> findAllByNameContainsIgnoreCaseOrCategoriesNameContainingIgnoreCase(String search,String categoryName);

}
