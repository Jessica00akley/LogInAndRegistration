package com.ProjectSchool.SchoolProject.controllers;

import com.ProjectSchool.SchoolProject.Repositories.BrandRepository;
import com.ProjectSchool.SchoolProject.Repositories.CategoryRepository;
import com.ProjectSchool.SchoolProject.Repositories.ItemRepository;
import com.ProjectSchool.SchoolProject.antities.Brand;
import com.ProjectSchool.SchoolProject.antities.Category;
import com.ProjectSchool.SchoolProject.antities.Item;
import com.ProjectSchool.SchoolProject.services.MyUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/market")
public class MarketController {
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private BrandRepository brandRepository;
    @Autowired
    private MyUserService myUserService;

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/home")
    public String openHome(Model model) {
        List<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        List<Item> items = itemRepository.findAll();
        model.addAttribute("items", items);
        List<Brand> brands = brandRepository.findAll();
        model.addAttribute("brands", brands);
        return "home";
    }

    @PostMapping(value = "/add-item")
    public String addItemPost(@RequestParam("item-name") String name,
                              @RequestParam("item-amount") int amount,
                              @RequestParam("item-price") int price,
                              @RequestParam("category-id") Long categoryId,
                              @RequestParam("brand-id") List<Brand> brands) {
        Category category = categoryRepository.findAllById(categoryId);
        categoryRepository.save(category);
        List<Category> categories = new ArrayList<>();
        categories.add(category);
        Item item = Item.builder()
                .name(name)
                .price(price)
                .amount(amount)
                .categories(categories)
                .brands(brands)
                .build();
        itemRepository.save(item);
        return "redirect:home";
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/details/{id}")
    public String detailsItem(@PathVariable("id") Long itemId, Model model) {
        List<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        Item item = itemRepository.findAllById(itemId);
        model.addAttribute("item", item);
        List<Brand> brands = brandRepository.findAll();
        model.addAttribute("brands", brands);
        return "details";
    }

    @PostMapping(value = "/update-item")
    public String updateItem(Item updateItem, @RequestParam("category-id") Long categoryId,
                             @RequestParam("brand-id") List<Brand> brands) {
        Category category = categoryRepository.findAllById(categoryId);

        categoryRepository.save(category);
        List<Category> categories = new ArrayList<>();
        categories.add(category);
        Item item = itemRepository.findAllById(updateItem.getId());
        item.setName(updateItem.getName());
        item.setPrice(updateItem.getPrice());
        item.setAmount(updateItem.getAmount());
        item.setCategories(categories);
        item.setBrands(brands);
        itemRepository.save(item);
        return "redirect:home";
    }

    @GetMapping(value = "/home-sorted")
    public String sortedItemPost(@RequestParam("sort") String sort, Model model) {
        List<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        if (sort != null && sort.equals("desc")) {
            List<Item> items = itemRepository.findAllByOrderByNameDesc();
            model.addAttribute("items", items);
        } else if (sort != null && sort.equals("asc")) {
            List<Item> items = itemRepository.findAllByOrderByNameAsc();
            model.addAttribute("items", items);
        }
        return "home";
    }

    @GetMapping(value = "/item-search")
    public String searchedItem(@RequestParam("search") String search, Model model) {
        List<Category> categories = categoryRepository.findAll();
        model.addAttribute("categories", categories);
        List<Item> items = null;
        for (int i = 0; i < search.length(); i++) {
            if (Character.isDigit(search.charAt(i))) {
                int numericValue = Integer.parseInt(search);
                items = itemRepository.findAllByAmountEqualsOrPriceEquals(numericValue, numericValue);
            } else {
                items=itemRepository.findAllByNameContainsIgnoreCaseOrCategoriesNameContainingIgnoreCase(search,search);
            }


        }
        model.addAttribute("items", items);
        return "home";
    }

    @PostMapping(value = "/delete")
    public String deleteItemPost(@RequestParam("item-id") Long id) {
        itemRepository.deleteById(id);
        return "redirect:home";
    }

    @PostMapping(value = "/delete-category")
    public String deleteCategoryOfItem(@RequestParam("category-id") Long categoryId,
                                       @RequestParam("item-id") Long itemId) {
        Item item = itemRepository.findAllById(itemId);
        int index = -1;
        for (int i = 0; i < item.getCategories().size(); i++) {
            if (item.getCategories().get(i).getId() == categoryId) {
                index = i;
                break;
            }

        }
        item.getBrands().clear();
        item.getCategories().remove(index);
        itemRepository.save(item);
        return "redirect:home";
    }

    @PreAuthorize("isAnonymous()")
    @GetMapping(value = "/login")
    public String openLogin() {
        return "login";
    }

    @GetMapping(value = "/403")
    public String openAccess() {
        return "403";
    }

    @PreAuthorize("isAnonymous()")
    @GetMapping(value = "/register")
    public String registerUser() {
        return "register";
    }

    @PostMapping(value = "/sign-up")
    public String signUpUser(@RequestParam("name") String name,
                             @RequestParam("surname") String surname,
                             @RequestParam("email") String email,
                             @RequestParam("password") String password,
                             @RequestParam("re-password") String rePassword) {
        String checkFlag = myUserService.signUp(name,surname, email, password, rePassword);
        if (checkFlag.equals("userExist")) {
            return "redirect:register?userExist";
        } else if (checkFlag.equals("passwordNotMatch")) {
            return "redirect:register?passwordNotMatch";
        } else {
            return "redirect:register?SuccessRegister";
        }
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/change-password")
    public String changePasswordOpen() {
        return "change-password";
    }

    @PostMapping(value = "/change-password")
    public String changePasswordPost(@RequestParam("current-email") String email,
                                     @RequestParam("current-password") String currentPassword,
                                     @RequestParam("new-password") String newPassword,
                                     @RequestParam("retype-password") String retypePassword) {

        String checkFlag = myUserService.changeUserPassword(email, currentPassword, newPassword, retypePassword);
        if (checkFlag.equals("userNotFound")) {
            return "redirect:change-password?userNotFound";
        } else if (checkFlag.equals("passwordWrong")) {
            return "redirect:change-password?passwordWrong";
        } else if (checkFlag.equals("newPasswordNotMatches")) {
            return "redirect:change-password?newPasswordNotMatches";
        } else {
            return "redirect:change-password?success";
        }
    }
}

